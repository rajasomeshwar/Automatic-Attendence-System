import logo from "./logo.svg";
import "./App.css";
import MiniProjectCompoment from "./MiniProjectCompoment/MiniProjectCompoment";
import App1 from "./MiniProjectCompoment/Swarj/src/App";
function App() {
  return <MiniProjectCompoment></MiniProjectCompoment>;

  // return <App1></App1>;
}

export default App;
