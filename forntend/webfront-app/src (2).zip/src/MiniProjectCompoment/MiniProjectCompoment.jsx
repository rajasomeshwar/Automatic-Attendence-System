import Home from "./LoginOutCompoments/Facultyanalysis/Home";
export default function MiniProjectCompoment() {
  return (
    <>
      <Home></Home>
    </>
  );
}
