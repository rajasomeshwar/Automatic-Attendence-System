function FooterComponent()
{
   
    return(
        <div className="Fotter">
          <hr />
            <h1>

           FOTTER
            
            </h1>
        </div>
    );
}
export default FooterComponent;