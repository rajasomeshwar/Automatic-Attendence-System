export default function ForgetPassWordCompoment() {
  return <div></div>;
}
