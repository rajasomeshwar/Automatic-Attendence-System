export default function LogoutComponent()
{
    return (
        <div className="logout">
        
          <h1>

        You Are signed out!
          
          </h1>
      </div>
    );
}