package com.testingImage.LearnImageStore.Image;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<byte[]> getPicturesForStudent(Long studentId) {
        List<Student> students = studentRepository.findByStudentid(studentId);
        return students.stream()
                       .map(Student::getPicture)
                       .toList();
    }
}
