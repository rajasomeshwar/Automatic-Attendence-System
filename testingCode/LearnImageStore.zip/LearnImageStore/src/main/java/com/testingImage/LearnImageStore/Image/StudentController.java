package com.testingImage.LearnImageStore.Image;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Base64;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/students")
@CrossOrigin("*")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/{id}/pictures")
    public ResponseEntity<List<byte[]>> getStudentPictures(@PathVariable Long id) {
        List<byte[]> images = studentService.getPicturesForStudent(id);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");  // Set to JSON since you're returning a list

        return new ResponseEntity<>(images, headers, HttpStatus.OK);
    }
}
